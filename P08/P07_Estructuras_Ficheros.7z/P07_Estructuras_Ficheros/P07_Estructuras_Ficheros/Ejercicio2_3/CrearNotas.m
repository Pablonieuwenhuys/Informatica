function notas = CrearNotas()
    notas = rand(1,10).*10;
end