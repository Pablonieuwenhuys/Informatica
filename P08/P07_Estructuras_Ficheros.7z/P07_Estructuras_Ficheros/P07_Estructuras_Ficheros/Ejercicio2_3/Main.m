


clear all
clc

while(1)
    disp(' ')
    disp(' ')
    disp(' ')
	disp('�Que desea hacer?.')
	disp('1.	Rellenar el vector inicial.')
	disp('2.	Mostrar todos los alumnos.')
	disp('3.	Mostrar los datos de un alumno.')
	disp('4.	Calcular la media de un alumno.')
	disp('5.	Calcular la media de cada asignatura.')
	disp('6.	Calcular el numero de suspensos de un alumno.')
	disp('7.	Calcular el numero de alumnos que han suspendido un numero determinado de asignaturas.')
	disp('8.	Salir.')
    
    opcion = input('Seleccione una opcion: ');
    
    if (opcion==1)
        
    elseif(opcion==2)
       
       
    elseif(opcion==3)
       
       
    elseif(opcion==4)
        
    elseif(opcion==5)
       
    elseif(opcion==6)
       
    elseif(opcion==7)
       
    elseif(opcion==8)
        
    end
end