
clear all
clc




while(1)
    disp(' ')
    disp(' ')
    disp(' ')
	disp('?Que desea hacer?.')
	disp('1.	Listar los contactos.')
	disp('2.	Buscar un contacto por nombre.')
	disp('3.	Anadir contacto a la agenda.')
	disp('4.	Borrar contacto.')
	disp('5.	Borrar contacto por nombre.')
	disp('6.	Modificar tono asociado.')
	disp('7.	Invertir status de amigo (por nombre).')
	disp('8.	Salir.')
    
    opcion = input('Seleccione una opcion: ');
    
    if (opcion==1)
      
        
    elseif(opcion==2)
        
        
    elseif(opcion==3)
        
       
        
    elseif(opcion==4)
        
      
       
        
    elseif(opcion==5)
       
        
    elseif(opcion==6)
        
        
    elseif(opcion==7)
        
        
        
    elseif(opcion==8)
        nombre = input('?Nombre del contacto? ');
       
        
    elseif(opcion==9)
        
    end
end